@echo off
cd /d "%~dp0"
"%~dp0.venv313\Scripts\python.exe" -m uvicorn api:app --host 127.0.0.1 --port 8000
pause
