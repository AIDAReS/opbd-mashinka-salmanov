from pathlib import Path
import zipfile

import numpy as np
from PIL import Image
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

import tf_keras


BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "model"
MODEL_ZIP = BASE_DIR / "converted_keras.zip"
IMAGE_SIZE = (224, 224)
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


class CompatibleDepthwiseConv2D(tf_keras.layers.DepthwiseConv2D):
    """Совместимость с конфигурацией DepthwiseConv2D из экспорта Teachable Machine."""
    @classmethod
    def from_config(cls, config):
        config = dict(config)
        config.pop("groups", None)
        return super().from_config(config)


def find_model_files():
    """Находит модель и labels.txt, при необходимости распаковывает ZIP."""
    MODEL_DIR.mkdir(exist_ok=True)

    model_files = list(MODEL_DIR.rglob("keras_model.h5"))
    label_files = list(MODEL_DIR.rglob("labels.txt"))

    if (not model_files or not label_files) and MODEL_ZIP.exists():
        with zipfile.ZipFile(MODEL_ZIP, "r") as archive:
            archive.extractall(MODEL_DIR)
        model_files = list(MODEL_DIR.rglob("keras_model.h5"))
        label_files = list(MODEL_DIR.rglob("labels.txt"))

    if not model_files:
        raise FileNotFoundError(
            "Не найдена модель keras_model.h5. Поместите converted_keras.zip "
            "рядом с api.py или файлы модели в папку model/."
        )
    if not label_files:
        raise FileNotFoundError(
            "Не найден labels.txt. Используйте полный экспорт Teachable Machine."
        )
    return model_files[0], label_files[0]


def read_labels(path: Path):
    labels = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(maxsplit=1)
        # Teachable Machine может записывать метки как "0 Class name".
        if len(parts) == 2 and parts[0].isdigit():
            line = parts[1].strip()
        labels.append(line)
    if not labels:
        raise ValueError("Файл labels.txt не содержит названий классов.")
    return labels


MODEL_PATH, LABELS_PATH = find_model_files()
CLASS_NAMES = read_labels(LABELS_PATH)

model = tf_keras.models.load_model(
    MODEL_PATH,
    compile=False,
    custom_objects={"DepthwiseConv2D": CompatibleDepthwiseConv2D},
)

if model.output_shape[-1] != len(CLASS_NAMES):
    raise RuntimeError(
        f"Количество выходов модели ({model.output_shape[-1]}) "
        f"не совпадает с количеством классов ({len(CLASS_NAMES)})."
    )

app = FastAPI(
    title="Aircraft Image Classification API",
    description=(
        "API для классификации изображений вертолётов, "
        "пассажирских самолётов и истребителей."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def preprocess_image(image: Image.Image):
    image = image.convert("RGB").resize(IMAGE_SIZE)
    array = np.asarray(image, dtype=np.float32)
    # Нормализация соответствует модели Teachable Machine (Keras).
    array = (array / 127.5) - 1.0
    return np.expand_dims(array, axis=0)


@app.get("/")
def root():
    return {
        "message": "Aircraft classification API is running",
        "docs": "/docs",
        "classes": CLASS_NAMES,
    }


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_loaded": True,
        "classes": CLASS_NAMES,
        "input_size": list(IMAGE_SIZE),
    }


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    filename = file.filename or "uploaded_image"
    suffix = Path(filename).suffix.lower()

    if suffix and suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail="Неподдерживаемый формат. Используйте JPG, PNG, BMP или WEBP.",
        )

    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Загружен пустой файл.")
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Размер изображения превышает 15 МБ.")

    try:
        from io import BytesIO
        image = Image.open(BytesIO(content))
        image.verify()
        image = Image.open(BytesIO(content))
        input_array = preprocess_image(image)
    except Exception:
        raise HTTPException(
            status_code=400,
            detail="Не удалось прочитать файл как изображение.",
        )

    probabilities = model.predict(input_array, verbose=0)[0]
    predicted_index = int(np.argmax(probabilities))
    confidence = float(probabilities[predicted_index])

    class_probabilities = [
        {
            "class_name": CLASS_NAMES[index],
            "probability": round(float(probabilities[index]), 6),
            "probability_percent": round(float(probabilities[index]) * 100, 2),
        }
        for index in range(len(CLASS_NAMES))
    ]

    return {
        "filename": filename,
        "predicted_class": CLASS_NAMES[predicted_index],
        "confidence": round(confidence, 6),
        "confidence_percent": round(confidence * 100, 2),
        "probabilities": class_probabilities,
        "note": (
            "Уверенность — вероятность, выданная моделью для выбранного класса; "
            "это не общая точность модели на тестовой выборке."
        ),
    }
