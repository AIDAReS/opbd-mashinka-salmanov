@echo off
cd /d "%~dp0"
"%~dp0.venv313\Scripts\python.exe" -m streamlit run gui.py --server.address 127.0.0.1
pause
