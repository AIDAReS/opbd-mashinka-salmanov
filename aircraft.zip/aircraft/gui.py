import io
import requests
import streamlit as st
from PIL import Image

API_URL = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="Распознавание летательных аппаратов",
    page_icon="✈️",
    layout="centered",
)

st.title("✈️ Распознавание летательных аппаратов")
st.write(
    "Загрузите изображение вертолёта, пассажирского самолёта или истребителя. "
    "Приложение отправит изображение в разработанный API и покажет результат."
)

with st.expander("Какие классы распознаёт модель?"):
    st.markdown(
        "- **Helicopter** — вертолёт\n"
        "- **Passenger Airplane** — пассажирский самолёт\n"
        "- **Fighter Jet** — истребитель"
    )

uploaded_file = st.file_uploader(
    "Выберите изображение",
    type=["jpg", "jpeg", "png", "bmp", "webp"],
)

if uploaded_file is not None:
    raw_bytes = uploaded_file.getvalue()

    try:
        image = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
        st.image(image, caption="Загруженное изображение", use_container_width=True)
    except Exception:
        st.error("Не удалось открыть файл как изображение.")
        st.stop()

    if st.button("Распознать изображение", type="primary", use_container_width=True):
        with st.spinner("Модель анализирует изображение..."):
            try:
                response = requests.post(
                    f"{API_URL}/predict",
                    files={
                        "file": (
                            uploaded_file.name,
                            raw_bytes,
                            uploaded_file.type or "application/octet-stream",
                        )
                    },
                    timeout=120,
                )

                if response.status_code != 200:
                    try:
                        message = response.json().get("detail", response.text)
                    except Exception:
                        message = response.text
                    st.error(f"Ошибка API ({response.status_code}): {message}")
                else:
                    result = response.json()
                    st.success("Распознавание завершено!")

                    st.subheader("Результат")
                    st.markdown(f"### {result['predicted_class']}")
                    st.metric(
                        "Уверенность модели",
                        f"{result['confidence_percent']:.2f}%",
                    )

                    st.subheader("Вероятности по всем классам")
                    for item in result["probabilities"]:
                        st.write(
                            f"**{item['class_name']}** — "
                            f"{item['probability_percent']:.2f}%"
                        )
                        st.progress(
                            min(max(float(item["probability"]), 0.0), 1.0)
                        )

                    st.caption(result.get("note", ""))
            except requests.exceptions.ConnectionError:
                st.error(
                    "Не удалось подключиться к API. Сначала запустите сервер "
                    "командой из README: uvicorn api:app --reload."
                )
            except requests.exceptions.Timeout:
                st.error("Сервер не ответил вовремя. Попробуйте ещё раз.")
            except requests.exceptions.RequestException as exc:
                st.error(f"Ошибка при обращении к API: {exc}")

st.divider()
st.caption("Клиентское приложение Streamlit • Серверная часть FastAPI")
